from .base_tool import BaseTool
from .web_search import WebSearchTool
from .file_manager import FileManager
from .ollama_tool import OllamaTool  # ← Ajouté ici clairement
