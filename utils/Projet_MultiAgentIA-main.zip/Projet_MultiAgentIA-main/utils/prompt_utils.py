class PromptUtils:
    @staticmethod
    def formater_prompt(prompt):
        return prompt.strip().capitalize()
