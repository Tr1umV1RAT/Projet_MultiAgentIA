from .base_role import BaseRole
from .climato_sceptique import ClimatoSceptique
from .scientifique import Scientifique
