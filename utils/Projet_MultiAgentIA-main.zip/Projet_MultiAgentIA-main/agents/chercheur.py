from agents.base_agent import BaseAgent

class Chercheur(BaseAgent):
    def __init__(self, nom="Chercheur"):
        super().__init__(nom)
