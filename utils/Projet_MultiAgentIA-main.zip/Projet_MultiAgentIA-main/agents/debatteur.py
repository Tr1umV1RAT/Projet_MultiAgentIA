from agents.base_agent import BaseAgent

class Debatteur(BaseAgent):
    def __init__(self, nom="Debatteur"):
        super().__init__(nom)
