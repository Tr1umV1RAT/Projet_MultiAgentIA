from .base_agent import BaseAgent
from .debatteur import Debatteur
from .chercheur import Chercheur
